from django.shortcuts import render
from django.contrib.auth.models import Group, User
from .models import Prodi, Siswa, Kuliah, Registrasi
from rest_framework import permissions, viewsets, filters, generics
# from django_filters.rest_framework import DjangoFilterBackend

from tutorial.quickstart.serializers import GroupSerializer, UserSerializer, ProdiSerializer, SiswaSerializer, KuliahSerializer, RegistrasiSerializer


class UserViewSet(viewsets.ModelViewSet):


    queryset = User.objects.all().order_by("-date_joined")
    serializer_class = UserSerializer
    permission_classes = [permissions.IsAuthenticated]

class GroupViewSet(viewsets.ModelViewSet):

    queryset = Group.objects.all().order_by("name")
    serializer_class = GroupSerializer
    permission_classes = [permissions.IsAuthenticated]
    
class ProdiViewSet(viewsets.ModelViewSet):
    queryset = Prodi.objects.all()
    serializer_class = ProdiSerializer
    permission_classes = [permissions.AllowAny]
    # filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    # filterset_fields = ['id', 'nama', 'kaprodi']
    # search_fields = ['nama', 'kaprodi']
    # ordering_fields = ['nama', 'kaprodi']

class SiswaViewSet(viewsets.ModelViewSet):
    queryset = Siswa.objects.all()
    serializer_class = SiswaSerializer
    permission_classes = [permissions.AllowAny]
    # filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    # filterset_fields = ['prodi', 'nim', 'id']
    # search_fields = ['nama', 'nim']
    # ordering_fields = ['nama', 'nim']

class KuliahViewSet(viewsets.ModelViewSet):
    queryset = Kuliah.objects.all()
    serializer_class = KuliahSerializer
    permission_classes = [permissions.AllowAny]
    # filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    # filterset_fields = ['prodi', 'hari', 'sks', 'id']
    # search_fields = ['matkul', 'hari']
    # ordering_fields = ['matkul', 'sks']

class RegistrasiViewSet(viewsets.ModelViewSet):
    queryset = Registrasi.objects.all()
    serializer_class = RegistrasiSerializer
    permission_classes = [permissions.AllowAny]
    # filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    # filterset_fields = ['siswa', 'kuliah', 'id']
    # search_fields = []
    # ordering_fields = ['id']

# URL-filtered list views
class SiswaByProdiList(generics.ListAPIView):
    serializer_class = SiswaSerializer
    permission_classes = [permissions.AllowAny]

    def get_queryset(self):
        prodi_nama = self.kwargs.get('prodi_nama')
        # filter by related Prodi.nama (case-insensitive exact match)
        return Siswa.objects.filter(prodi__nama__iexact=prodi_nama)

class KuliahByProdiList(generics.ListAPIView):
    serializer_class = KuliahSerializer
    permission_classes = [permissions.AllowAny]

    def get_queryset(self):
        prodi_nama = self.kwargs.get('prodi_nama')
        # filter by related Prodi.nama (case-insensitive exact match)
        return Kuliah.objects.filter(prodi__nama__iexact=prodi_nama)

class RegistrasiBySiswaList(generics.ListAPIView):
    serializer_class = RegistrasiSerializer
    permission_classes = [permissions.AllowAny]

    def get_queryset(self):
        siswa_id = self.kwargs.get('siswa_id')
        return Registrasi.objects.filter(siswa_id=siswa_id)

# filter registrasi by kuliah name (matkul)
class RegistrasiByKuliahList(generics.ListAPIView):
    serializer_class = RegistrasiSerializer
    permission_classes = [permissions.AllowAny]

    def get_queryset(self):
        kuliah_matkul = self.kwargs.get('kuliah_matkul')
        # case-insensitive exact match; ganti ke __icontains untuk partial match
        return Registrasi.objects.filter(kuliah__matkul__iexact=kuliah_matkul)
