(function ($) {
  "use strict";
  
    alert('abc');

})(jQuery);
